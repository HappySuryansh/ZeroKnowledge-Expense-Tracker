// src/api/categorizationClient.ts

export interface CategorizationResponse {
  categoryMap: Record<string, string>;
}

export async function categorizeMerchantsStateless(
  apiBaseUrl: string,
  jwtToken: string,
  isolatedMerchants: string[]
): Promise<Record<string, string>> {
  const response = await fetch(`${apiBaseUrl}/api/v1/categorize`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${jwtToken}`,
    },
    // Outbound payload strictly contains ONLY the string array of isolated merchants
    body: JSON.stringify({ merchants: isolatedMerchants }),
  });

  if (response.status === 429) {
    throw new Error('Rate limit exceeded for this device token.');
  }

  if (!response.ok) {
    throw new Error(`Categorization request failed with status ${response.status}`);
  }

  const data: CategorizationResponse = await response.json();
  return data.categoryMap;
}